<?php
    
############################################################
#######                                             ########
#######                                             ########
#######           www.brshares.com 2.0              ########
#######                                             ########
#######                                             ########
############################################################
  
  require_once("backend/functions.php");
  dbconn(true);
  loggedinonly();
  
  stdhead("DONATE");

  begin_framec(T_("DONATE"));
  
  ?>
<center>
Para manter-mos o site com boa estrutura não é fácil ,temos um grande gasto com a manutenção do nosso servidor que vica hospedado em um dos melhores datacenter da europa .
<br><br>
Ajudando com sua doação , você garante nossa permanência no ar e voce ainda, baixa todos torrents <font color="green"><b>FREE</b></font>, sem preocupação com seu <b>Ratio</b><br><br>

Faça sua parte ajude-nos a manter nosso site no ar e sempre com boa qualidade e estrutura. <br><br>Veja as opções para ser um usuário VIP:<br><br></center><table cellspacing="0" width="100%" border="1" cellpadding="0" align="center" id="tabela1">
<br><br>
<tbody><tr>
<td align="center" width="100%" border="1" colspan="4" class="ttable_head"><b>Doação Mensal</b></td>
</tr><tr>

<td width="20%" align="center" class="tab1_cab1">BR VIP</td>
<td width="20%" align="center" class="tab1_cab1">BR VIP BRONZE</td>
<td width="20%" align="center" class="tab1_cab1">BR VIP PRATA</td>
<td width="20%" align="center" class="tab1_cab1">BR VIP OURO</td>
</tr>

<tr>
<td width="20%" align="center" class="tab1_col3">+ 5 BR-Bônus</td>
<td width="20%" align="center" class="tab1_col3">+ 25 BR-Bônus</td>
<td width="20%" align="center" class="tab1_col3">+ 30 BR-Bônus</td>
<td width="20%" align="center" class="tab1_col3">+ 50 BR-Bônus</td>
</tr>

<tr>
<td width="20%" align="center" class="tab1_col3">+ 5 GB de upload</td>
<td width="20%" align="center" class="tab1_col3">+ 10 GB de upload</td>
<td width="20%" align="center" class="tab1_col3">+ 25 GB de upload</td>
<td width="20%" align="center" class="tab1_col3">+ 30 GB de upload</td>
</tr>

<tr>
<td width="20%" align="center" class="tab1_col3">-</td>
<td width="20%" align="center" class="tab1_col3">+ 1 convite</td>
<td width="20%" align="center" class="tab1_col3">+ 3 convites</td>
<td width="20%" align="center" class="tab1_col3">+ 5 convites</td>
</tr>



<tr>
<td width="20%" align="center" class="tab1_col3"><b>R$ 10,00</b> <BR> <a mp-mode="dftl" href="https://www.mercadopago.com/mlb/checkout/start?pref_id=216625569-54e43ff9-8988-4298-aa68-c9db0cbba1e3" name="MP-payButton" class='lightBlue-tr-l-rn-bron'>DOAR</a>
<script type="text/javascript">
(function(){function $MPC_load(){window.$MPC_loaded !== true && (function(){var s = document.createElement("script");s.type = "text/javascript";s.async = true;s.src = document.location.protocol+"//secure.mlstatic.com/mptools/render.js";var x = document.getElementsByTagName('script')[0];x.parentNode.insertBefore(s, x);window.$MPC_loaded = true;})();}window.$MPC_loaded !== true ? (window.attachEvent ?window.attachEvent('onload', $MPC_load) : window.addEventListener('load', $MPC_load, false)) : null;})();
</script></td>

<td width="20%" align="center" class="tab1_col3"><b>R$ 15,00</b> <BR> <a mp-mode="dftl" href="https://www.mercadopago.com/mlb/checkout/start?pref_id=216625569-be658fe7-643e-44dc-b197-7b0a2eb49384" name="MP-payButton" class='grey-tr-l-rn-bron'>DOAR</a>
<script type="text/javascript">
(function(){function $MPC_load(){window.$MPC_loaded !== true && (function(){var s = document.createElement("script");s.type = "text/javascript";s.async = true;s.src = document.location.protocol+"//secure.mlstatic.com/mptools/render.js";var x = document.getElementsByTagName('script')[0];x.parentNode.insertBefore(s, x);window.$MPC_loaded = true;})();}window.$MPC_loaded !== true ? (window.attachEvent ?window.attachEvent('onload', $MPC_load) : window.addEventListener('load', $MPC_load, false)) : null;})();
</script></td>
<td width="20%" align="center" class="tab1_col3"><b>R$ 30,00</b> <BR> <a mp-mode="dftl" href="https://www.mercadopago.com/mlb/checkout/start?pref_id=216625569-ec35cb5d-4a6e-44ef-92a8-e8d8b6cab4a2" name="MP-payButton" class='lightBlue-ar-l-rn-bron'>DOAR</a>
<script type="text/javascript">
(function(){function $MPC_load(){window.$MPC_loaded !== true && (function(){var s = document.createElement("script");s.type = "text/javascript";s.async = true;s.src = document.location.protocol+"//secure.mlstatic.com/mptools/render.js";var x = document.getElementsByTagName('script')[0];x.parentNode.insertBefore(s, x);window.$MPC_loaded = true;})();}window.$MPC_loaded !== true ? (window.attachEvent ?window.attachEvent('onload', $MPC_load) : window.addEventListener('load', $MPC_load, false)) : null;})();
</script></td>
<td width="20%" align="center" class="tab1_col3"><b>R$ 50,00</b> <BR> <a mp-mode="dftl" href="https://www.mercadopago.com/mlb/checkout/start?pref_id=216625569-4895895f-1fa9-490f-847e-9f6fd6cff071" name="MP-payButton" class='grey-ar-l-rn-bron'>DOAR</a>
<script type="text/javascript">
(function(){function $MPC_load(){window.$MPC_loaded !== true && (function(){var s = document.createElement("script");s.type = "text/javascript";s.async = true;s.src = document.location.protocol+"//secure.mlstatic.com/mptools/render.js";var x = document.getElementsByTagName('script')[0];x.parentNode.insertBefore(s, x);window.$MPC_loaded = true;})();}window.$MPC_loaded !== true ? (window.attachEvent ?window.attachEvent('onload', $MPC_load) : window.addEventListener('load', $MPC_load, false)) : null;})();
</script></td>
</tr>

</tbody></table><br><br><table cellspacing="0"  width="100%" border="1"  cellpadding="0" align="center" id="tabela1">

<tbody><tr>
<td align="center" colspan="4" class="ttable_head"><b>Doação Trimestral</b></td>
</tr>

<tr>
<td width="20%" align="center" class="tab1_cab1">BR VIP</td>
<td width="20%" align="center" class="tab1_cab1">BR VIP BRONZE</td>
<td width="20%" align="center" class="tab1_cab1">BR VIP PRATA</td>
<td width="20%" align="center" class="tab1_cab1">BR VIP OURO</td>
</tr>

<tr>
<td width="20%" align="center" class="tab1_col3">+ 30 BR-Bônus</td>
<td width="20%" align="center" class="tab1_col3">+ 45 BR-Bônus</td>
<td width="20%" align="center" class="tab1_col3">+ 60 BR-Bônus</td>
<td width="20%" align="center" class="tab1_col3">+ 90 BR-Bônus</td>
</tr>

<tr>
<td width="20%" align="center" class="tab1_col3">+ 15 GB de upload</td>
<td width="20%" align="center" class="tab1_col3">+ 20 GB de upload</td>
<td width="20%" align="center" class="tab1_col3">+ 30 GB de upload</td>
<td width="20%" align="center" class="tab1_col3">+ 45 GB de upload</td>
</tr>

<tr>
<td width="20%" align="center" class="tab1_col3">+ 2 convite</td>
<td width="20%" align="center" class="tab1_col3">+ 4 convites</td>
<td width="20%" align="center" class="tab1_col3">+ 8 convites</td>
<td width="20%" align="center" class="tab1_col3">+ 12 convites</td>
</tr>



<tr>
<td width="20%" align="center" class="tab1_col3"><b>R$ 35,00</b>  <BR><a mp-mode="dftl" href="https://www.mercadopago.com/mlb/checkout/start?pref_id=216625569-58c3b938-2200-46d5-820b-c7be6cdd5bd2" name="MP-payButton" class='lightBlue-ar-l-rn-bron'>DOAR</a>
<script type="text/javascript">
(function(){function $MPC_load(){window.$MPC_loaded !== true && (function(){var s = document.createElement("script");s.type = "text/javascript";s.async = true;s.src = document.location.protocol+"//secure.mlstatic.com/mptools/render.js";var x = document.getElementsByTagName('script')[0];x.parentNode.insertBefore(s, x);window.$MPC_loaded = true;})();}window.$MPC_loaded !== true ? (window.attachEvent ?window.attachEvent('onload', $MPC_load) : window.addEventListener('load', $MPC_load, false)) : null;})();
</script></td>
<td width="20%" align="center" class="tab1_col3"><b>R$ 70,00</b>  <BR><a mp-mode="dftl" href="https://www.mercadopago.com/mlb/checkout/start?pref_id=216625569-42f0ba32-66c6-4007-a39b-3f9ffa322d4c" name="MP-payButton" class='grey-ar-l-rn-bron'>DOAR</a>
<script type="text/javascript">
(function(){function $MPC_load(){window.$MPC_loaded !== true && (function(){var s = document.createElement("script");s.type = "text/javascript";s.async = true;s.src = document.location.protocol+"//secure.mlstatic.com/mptools/render.js";var x = document.getElementsByTagName('script')[0];x.parentNode.insertBefore(s, x);window.$MPC_loaded = true;})();}window.$MPC_loaded !== true ? (window.attachEvent ?window.attachEvent('onload', $MPC_load) : window.addEventListener('load', $MPC_load, false)) : null;})();
</script></td>
<td width="20%" align="center" class="tab1_col3"><b>R$ 100,00</b> <BR><a mp-mode="dftl" href="https://www.mercadopago.com/mlb/checkout/start?pref_id=216625569-28e1a93e-268b-41dc-b1c8-ca0d02a9386c" name="MP-payButton" class='lightBlue-tr-l-rn-bron'>DOAR</a>
<script type="text/javascript">
(function(){function $MPC_load(){window.$MPC_loaded !== true && (function(){var s = document.createElement("script");s.type = "text/javascript";s.async = true;s.src = document.location.protocol+"//secure.mlstatic.com/mptools/render.js";var x = document.getElementsByTagName('script')[0];x.parentNode.insertBefore(s, x);window.$MPC_loaded = true;})();}window.$MPC_loaded !== true ? (window.attachEvent ?window.attachEvent('onload', $MPC_load) : window.addEventListener('load', $MPC_load, false)) : null;})();
</script></td>
<td width="20%" align="center" class="tab1_col3"><b>R$ 140,00</b>  <BR><a mp-mode="dftl" href="https://www.mercadopago.com/mlb/checkout/start?pref_id=216625569-8ad5425d-e079-4bc6-a757-c5ba2f277587" name="MP-payButton" class='grey-tr-l-rn-bron'>DOAR</a>
<script type="text/javascript">
(function(){function $MPC_load(){window.$MPC_loaded !== true && (function(){var s = document.createElement("script");s.type = "text/javascript";s.async = true;s.src = document.location.protocol+"//secure.mlstatic.com/mptools/render.js";var x = document.getElementsByTagName('script')[0];x.parentNode.insertBefore(s, x);window.$MPC_loaded = true;})();}window.$MPC_loaded !== true ? (window.attachEvent ?window.attachEvent('onload', $MPC_load) : window.addEventListener('load', $MPC_load, false)) : null;})();
</script></td>
</tr>

</tbody></table><br><br>

<table cellspacing="0" cellpadding="0"  width="100%" border="1"  align="center" id="tabela1">

<tbody><tr>
<td align="center" colspan="4" class="ttable_head"><b>Doação Semestral</b></td>
</tr>

<tr>
<td width="20%" align="center" class="tab1_cab1">BR VIP</td>
<td width="20%" align="center" class="tab1_cab1">BR VIP BRONZE</td>
<td width="20%" align="center" class="tab1_cab1">BR VIP PRATA</td>
<td width="20%" align="center" class="tab1_cab1">BR VIP OURO</td>
</tr>

<tr>
<td width="20%" align="center" class="tab1_col3">+ 50 BR-Bônus</td>
<td width="20%" align="center" class="tab1_col3">+ 80 BR-Bônus</td>
<td width="20%" align="center" class="tab1_col3">+ 120 BR-Bônus</td>
<td width="20%" align="center" class="tab1_col3">+ 200 BR-Bônus</td>
</tr>

<tr>
<td width="20%" align="center" class="tab1_col3">+ 25 GB de upload</td>
<td width="20%" align="center" class="tab1_col3">+ 35 GB de upload</td>
<td width="20%" align="center" class="tab1_col3">+ 50 GB de upload</td>
<td width="20%" align="center" class="tab1_col3">+ 100 GB de upload</td>
</tr>

<tr>
<td width="20%" align="center" class="tab1_col3">+ 5 convites</td>
<td width="20%" align="center" class="tab1_col3">+ 10 convites</td>
<td width="20%" align="center" class="tab1_col3">+ 15 convites</td>
<td width="20%" align="center" class="tab1_col3">+ 25 convites</td>
</tr>



<tr>
<td width="20%" align="center" class="tab1_col3"><b>R$ 50,00</b><BR> <a mp-mode="dftl" href="https://www.mercadopago.com/mlb/checkout/start?pref_id=216625569-1d2de69d-3380-4fcd-86c5-2fc13bc096cd" name="MP-payButton" class='lightBlue-tr-l-rn-bron'>DOAR</a>
<script type="text/javascript">
(function(){function $MPC_load(){window.$MPC_loaded !== true && (function(){var s = document.createElement("script");s.type = "text/javascript";s.async = true;s.src = document.location.protocol+"//secure.mlstatic.com/mptools/render.js";var x = document.getElementsByTagName('script')[0];x.parentNode.insertBefore(s, x);window.$MPC_loaded = true;})();}window.$MPC_loaded !== true ? (window.attachEvent ?window.attachEvent('onload', $MPC_load) : window.addEventListener('load', $MPC_load, false)) : null;})();
</script></td>
<td width="20%" align="center" class="tab1_col3"><b>R$ 100,00</b><BR> <a mp-mode="dftl" href="https://www.mercadopago.com/mlb/checkout/start?pref_id=216625569-d37f831e-9764-41db-8eae-1154e4672507" name="MP-payButton" class='grey-tr-l-rn-bron'>DOAR</a>
<script type="text/javascript">
(function(){function $MPC_load(){window.$MPC_loaded !== true && (function(){var s = document.createElement("script");s.type = "text/javascript";s.async = true;s.src = document.location.protocol+"//secure.mlstatic.com/mptools/render.js";var x = document.getElementsByTagName('script')[0];x.parentNode.insertBefore(s, x);window.$MPC_loaded = true;})();}window.$MPC_loaded !== true ? (window.attachEvent ?window.attachEvent('onload', $MPC_load) : window.addEventListener('load', $MPC_load, false)) : null;})();
</script></td>
<td width="20%" align="center" class="tab1_col3"><b>R$ 150,00</b><BR> <a mp-mode="dftl" href="https://www.mercadopago.com/mlb/checkout/start?pref_id=216625569-34001c37-b2a1-41f1-b9e9-5ed73c7f5e3a" name="MP-payButton" class='lightBlue-tr-l-rn-bron'>DOAR</a>
<script type="text/javascript">
(function(){function $MPC_load(){window.$MPC_loaded !== true && (function(){var s = document.createElement("script");s.type = "text/javascript";s.async = true;s.src = document.location.protocol+"//secure.mlstatic.com/mptools/render.js";var x = document.getElementsByTagName('script')[0];x.parentNode.insertBefore(s, x);window.$MPC_loaded = true;})();}window.$MPC_loaded !== true ? (window.attachEvent ?window.attachEvent('onload', $MPC_load) : window.addEventListener('load', $MPC_load, false)) : null;})();
</script></td>
<td width="20%" align="center" class="tab1_col3"><b>R$ 200,00</b><BR> <a mp-mode="dftl" href="https://www.mercadopago.com/mlb/checkout/start?pref_id=216625569-17889685-f3f4-4f3b-9cdf-363fce08519b" name="MP-payButton" class='grey-tr-l-rn-bron'>DOAR</a>
<script type="text/javascript">
(function(){function $MPC_load(){window.$MPC_loaded !== true && (function(){var s = document.createElement("script");s.type = "text/javascript";s.async = true;s.src = document.location.protocol+"//secure.mlstatic.com/mptools/render.js";var x = document.getElementsByTagName('script')[0];x.parentNode.insertBefore(s, x);window.$MPC_loaded = true;})();}window.$MPC_loaded !== true ? (window.attachEvent ?window.attachEvent('onload', $MPC_load) : window.addEventListener('load', $MPC_load, false)) : null;})();
</script></td>
</tr>

</tbody></table><br><br>

<a name="metodos"></a>
<table cellspacing="1" cellpadding="0"  width="100%" align="center" id="tabela1">
<tbody><tr><td align="center" class="tab1_cab1">
Outros Métodos de Doação
</td></tr><tr><td style="line-height: 2.2em;" class="tab1_col3">
<font size="2" color="#006699"><b>Banco - Depósito em Conta Corrente / Transferência</b></font><br><br>
		<font size="2">
		Banco: <b>Banco do Brasil - xxx</b><br>
		Agência: <b>xxxx-x</b><br>x
		Conta Corrente: <b>xx.xxx-x</b><br>
		Favorecido: <b>xxxxxxx</b><br>
		</font><br>
		
		
		<hr>


		
</td></tr></tbody></table><br>


<table cellspacing="1" cellpadding="0"  width="100%" align="center" id="tabela1">
<tbody><tr><td align="center" class="tab1_cab1">
Confirmação de doação
</td></tr><tr><td align="center" class="tab1_col3">
<font size="3" color="#006699"><b>ATENÇÃO!!!</b></font>
<br>
A sua doação só será reconhecida após o envio do formulário de confirmação.<br><br>

<a href="doacao_confirma.php"><b><font size="2" color="#FF0000">Clique aqui para confirmar a doação!</font></b></a>
<br><br><br>
Aguarde a confirmação da doação. Isso deve levar em torno de 3 dias úteis. Caso o prazo termine, envie um email para contato@brshares.com informando o atraso.
</td></tr></tbody></table><br>

				<div class="clr"></div>



	

 <?php 
  end_framec();
  stdfoot();
  
?>