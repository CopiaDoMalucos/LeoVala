<?
echo"test";
print("test");
?>