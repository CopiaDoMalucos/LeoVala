<?php
############################################################
#######                                             ########
#######                                             ########
#######           malucos-share.org 2.0             ########
#######                                             ########
#######                                             ########
############################################################
require_once("backend/smilies.php");
require_once("backend/functions.php");
require_once("backend/config.php");


dbconn();
	
	?>
	<head>


</head>	
<body onLoad="setSurface();" >
<div id="emission_en_cours">

		<span>


		<CENTER><iframe src="http://www.malucos-share.org/player/index.php" 
marginwidth="0" marginheight="0" width="358" frameborder="0" 
height="240" scrolling="No"></iframe></CENTER></div>

	<CENTER> <a href='http://suaradio.taaqui.org/player/8108/winamp'><img src='http://suaradio.taaqui.org/admin/img/img-player-winamp.gif' title='' border='0' height='25' width='25'></a>
<a href='http://suaradio.taaqui.org/player/8108/mediaplayer'><img src='http://suaradio.taaqui.org/admin/img/img-player-mediaplayer.gif' title='' border='0' height='25' width='25'></a>
<a href='http://suaradio.taaqui.org/player/8108/realplayer'><img src='http://suaradio.taaqui.org/admin/img/img-player-realplayer.gif' title='' border='0' height='25' width='25'></a>
<a href="http://suaradio.taaqui.org/ios/8108.m3u"><img src="http://suaradio.taaqui.org/celulares/iphone-ipod-ipad-tablet.png" width="25" height="25" /></a>
<a href="rtsp://198.15.120.190:1935/shoutcast/mob8108.stream"><img src="http://suaradio.taaqui.org/celulares/android.png" width="25" height="25" /></a>
<a href="rtsp://198.15.120.190:1935/shoutcast/mob8108.stream"><img src="http://suaradio.taaqui.org/celulares/blackberry.png" width="25" height="25" /></a>
<a href="http://198.15.120.190:1935/shoutcast/mob8108.stream/playlist.m3u8"><img src="http://suaradio.taaqui.org/celulares/iphone-ipod-ipad-tablet.png" width="25" height="25" /></a>
<a href="http://198.15.120.190:1935/shoutcast/mob8108.stream/Manifest"><img src="http://suaradio.taaqui.org/celulares/phone-silverlight.png" width="25" height="25" /></a>


</CENTER>

    <?php


	

?>