<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>player</title>
<script type="text/javascript" src="swfobject.js"></script>
</head>
<body bgcolor="">
<table width="200" border="0" cellspacing="0" cellpadding="0" >
  <tr>
    

    <td width="135" valign="middle"><div id="flashcreaplayer">
</div>

<script type="text/javascript">
							// <![CDATA[
							
							var so = new SWFObject("dewplayer-stream.swf", "singsing", "135", "50", "7", "#000000");
							so.addVariable("mp3", "http://198.24.147.199:8108/;");
						  so.addParam("wmode", "transparent");
						  so.addVariable("autostart", "1");
							so.write("flashcreaplayer");
							
							// ]]>
						</script></td>
  </tr>

</table>

</body>



