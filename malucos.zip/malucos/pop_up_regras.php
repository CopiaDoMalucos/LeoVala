<?php
############################################################
#######                                             ########
#######                                             ########
#######           malucos-share.org 2.0             ########
#######                                             ########
#######                                             ########
############################################################
require_once("backend/functions.php");
dbconn(true);
	


		?>
<div class="myContent"><br>
<br>
<b><font size="2">
-> Ter 30 dias de cadastro no site.<br>
-> Ter no mínimo 1.00 de ratio.<br>
-> Aceitar em um todo e seguir a risca as regras da Radio.<br>
-> Ter a candidatura aprovada pela Moderação da Radio e ser aceito pela Administração do Site.<br><br><br>
</font></b>
<b><font size="2">1.0 &nbsp;-</font></b> Regras da Rádio Malucos Share: <br>
<br>
<b><font size="2">1.1 -</font></b> Respeitar os demais usuários, cientes de que os Dj's fazem parte do Staff do Malucos Share.<br>
<br>
<b><font size="2">1.2 &ndash;</font></b> É proibido digitar palavras de baixo calão no Shoutbox, assim como dizê-las no microfone.<br>
<br>
<b><font size="2">1.3 &ndash;</font></b> O membro tem que ter ratio sempre acima de 1.0  e manter esse ratio enquanto for Dj.<br>
<br>
<b><font size="2">1.4 &ndash;</font></b> Conduta exemplar, sem advertências<br>
<br>
<b><font size="2">1.5 &ndash;</font></b> Caso venha a ser advertido será destituído do cargo.<br>
</div>

<div class="myContent"><br>
<br>
<b><font size="2">2.0 &nbsp;-</font></b> Quanto às faltas: <br>
<br>
<b><font size="2">2.1 -</font></b> O Dj que tiver 03 faltas ou 50% de seu horário não justificadas, perderá os seus horários na grade fixa.<br>
<br>
<b><font size="2">2.2 &ndash;</font></b> Avisar com 24 horas de antecedência sobre a falta, ou se acontecer algum imprevisto, 01 ou 02 horas no máximo, antes do início do horário.<br>
<br>
<b><font size="2">2.3 &ndash;</font></b> O Dj que não responder a MP ou E-mail por motivo de falta, depois de 03 tentativas, será considerado abandono de função.<br>
<br>
<b><font size="2">2.4 &ndash;</font></b> Não será tolerada faltas sem Justificativa Plausível.<br>
<br>
<b><font size="2">2.5 &ndash;</font></b> O Dj deverá cumprir os seus horários, Não ultrapassando 5 minutos para mais ou para menos. (Tempo Máximo!). Salvo algum imprevisto, avisando ao próximo Dj caso for necessário ultrapassar o horário.<br>
<br>
</div>
		
<div class="myContent"><br>
<br>
<b><font size="2">3.0 &nbsp;-</font></b> Quanto a Conduta <br>
<br>
<b><font size="2">3.1 -</font></b> É expressamente proibido deixar a Rádio em "Playlist". Isso afasta os Users do Shoutbox e é um incomodo aos ouvintes, já que as musicas ficam repetindo.<br>
<br>
<b><font size="2">3.2 &ndash;</font></b> O Dj que for flagrado em Playlist será advertido e após 03 advertências será convidado a se retirar da Rádio.<br>
<br>
<b><font size="2">3.3 &ndash;</font></b> É EXPRESSAMENTE PROIBIDO deixar ativada a ferramenta de auto-reconexão (Auto Reconnect) do SimpleCast ou Shoutcast.<br>
<br>
<b><font size="2">3.4 &ndash;</font></b> Interagir com os Ouvintes/Usuários pelo Microfone em um Intervalo menos ou igual a 20 min. Sem esquecer de participar do Shoutbox, convidando os usuários do site a participarem também.<br>
<br>
<b><font size="2">3.5 &ndash;</font></b> OS Dj's devem aceitar Pedidos em sua programação normal, mesmo que não se enquadre no estilo do Dj. Exceção apenas em programas especiais, quando os pedidos devem ser relativos ao tema.<br>
<br>
<b><font size="2">3.6 &ndash;</font></b> Em caso de especiais, o Dj precisara da autorização do Moderador da Rádio ou da Administração do Site e avisar via fórum que realizara o especial indicando data e horário.<br>
<br>
<b><font size="2">3.7 &ndash;</font></b> Permitido anunciar Torrents Liberados e outros avisos pertinentes ao Site e/ou ao Staff, assim como parabenizar aniversariantes do dia.<br>
<br>
<b><font size="2">3.8 &ndash;</font></b> Os Dj's da Radio que estiverem online durante algum período de silêncio da Rádio, fica permitida a conexão ao servidor, sendo obrigatório o anúncio do motivo pelo qual conectou (falta de Dj para aquele horário) pelo Shoutbox ou pelo microfone, bem como anunciar as formas de se candidatar a Dj. Devendo o mesmo se desconectar assim que o Dj do horário chegar.<br>
<br>
<b><font size="2">3.9 &ndash;</font></b> O Dj que sair da Radio, observará uma carência de 60 dias, ou, a critério da administração.<br>
<br>
<b><font size="2">3.10 &ndash;</font></b> Respeitar os demais DJ's, Auxiliares, Moderador e ADM's.<br>
<br>

<div class="myContent"><br>
<br>
<b><font size="2">4.0 &nbsp;-</font></b> Punições <br>
<br>
<b><font size="2">4.1 -</font></b> Ao DJ, após 3 advertências sem justificativa, ou não se enquadrar dentro das regras da Radio, será convidado a se retirar da Rádio.<br>
<br>
<b><font size="2">4.2 &ndash;</font></b> O DJ que esquecer de desconectar do player da rádio por 02 vezes em menos de 01 mês recebera uma advertência e ficara sem poder conectar por 15 dias. Caso desrespeite essa regra de não conectar na Rádio nesse período, receberá mais 15 dias de advertência. (Salvo se tiver autorização do Moderador ou ADM).<br>
<br>
<b><font size="2">4.3 &ndash;</font></b> O DJ que não respeitar as regras do site recebera uma advertência e ficara 15 dias sem poder conectar, igualmente na regra acima.(Por exemplo: Flood, Palavras de baixo calão, etc.)<br>
<br>
<b><font size="2">-> Lembrando sempre que é Regra e Orientação não veicular Músicas contendo palavras de baixo calão, palavrões, menções e insinuações Sexuais,  apologia a drogas, crimes ou violência de qualquer natureza, menção a Times de esportes em geral, desrespeito a crença ou religião, menções e insinuações ao sexo explicito.</font></b><br>
<br>
<b><font size="2">-> O Bom Senso e o Respeito são imprescindíveis e sempre serão cobrados.</font></b> <br>
<br>

<b><font size="2">Essas Regras podem ser alteradas sem aviso prévio.<br>

Atenciosamente<br>


Moderação e Coordenação Radio Malucos Share</font></b> <br>

</div>

</div>	

	  <?php


	

	

?>