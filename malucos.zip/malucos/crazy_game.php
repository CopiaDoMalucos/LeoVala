
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Sistema De Mensagens</title>


</head>
<body>
	<div id="mensagens">
    	<ul>

        </ul>
    </div>
    <div id="conteudo">
    
    </div>
</body>
</html>