<?php

############################################################
#######                                             ########
#######                                             ########
#######           malucos-share.org 2.0             ########
#######                                             ########
#######                                             ########
############################################################
begin_blockT("Comunidade oficial");
?>

<center>
    <a href="http://www.facebook.com/groups/242957942441666/" target="_blank"><img
      src="images/1342656764_icontexto-user-web20-facebook.png" alt="face" title="face" height="48" width="48" /></a>
      
    <a href="http://www.orkut.com.br/Main#Community?cmm=121684501&1331484321" target="_blank"><img
      src="images/1342656219_icontexto-user-web20-orkut.png" alt="orkut" title="orkut" height="48" width="48" /></a>
</center>
  
<?php
end_block();
?>